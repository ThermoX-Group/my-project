<template>
    <div class="overflow-x-auto">
        <table class="table">
            <!-- head -->
            <thead>
                <tr>
                    <th>ماه</th>
                    <th>میزان فروش</th>
                    <th>بازدید کنندگان</th>
                    <th>خریداران</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>فروردین</th>
                    <td>37M</td>
                    <td>239 نفر</td>
                    <td>26 نفر</td>
                </tr>
                <tr>
                    <th>اردیبهشت</th>
                    <td>46M</td>
                    <td>496 نفر</td>
                    <td>37 نفر</td>
                </tr>
                <tr>
                    <th>خرداد</th>
                    <td>52M</td>
                    <td>347 نفر</td>
                    <td>40 نفر</td>
                </tr>
                <tr>
                    <th>تیر</th>
                    <td>23M</td>
                    <td>402 نفر</td>
                    <td>76 نفر</td>
                </tr>
                <tr>
                    <th>مرداد</th>
                    <td>19M</td>
                    <td>105 نفر</td>
                    <td>19 نفر</td>
                </tr>
                <tr>
                    <th>شهریور</th>
                    <td>40M</td>
                    <td>275 نفر</td>
                    <td>24 نفر</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>