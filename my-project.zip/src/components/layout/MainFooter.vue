<template>
    <footer class="bg-blue-300 p-4 pb-2 mx-10 mb-2 mt-4 rounded-2xl text-blue-800">
        <aside>
            <div class="flex justify-between items-center text-xl">
                <p>© کلیه حقوق این سایت محفوظ و متعلق به فروشگاه اینترنتی کتاب ترموبوک است.</p>
                <div>
                    <i class="fa-brands fa-telegram"></i>
                    <i class="fa-brands fa-instagram mr-3"></i>
                    <i class="fa-brands fa-twitter mr-3"></i>
                    <i class="fa-brands fa-facebook mr-3"></i>
                </div>
            </div>
            <p class="text-center border-t border-blue-400 mt-1 pt-1">🔥Designed By AmirBrzgr</p>
        </aside>
    </footer>
</template>