<template>
    <div>
        <slot name="introductionBook"></slot>
        <slot name="aboutBook"></slot>
    </div>
</template>